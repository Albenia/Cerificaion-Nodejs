

docker-compose up 

docker-compose down