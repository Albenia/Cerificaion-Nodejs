# start mongodb

mongod

# dbName : db_media
# collections : news_list, contactus_list

# start media-admin server at localhost:9900

cd media-admin
npm start

# start media-cust app at localhost:9901

cd media-cust
npm start
