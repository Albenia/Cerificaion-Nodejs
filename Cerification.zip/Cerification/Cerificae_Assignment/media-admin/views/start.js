require('@babel/register')({})
module.exports = require('./server')